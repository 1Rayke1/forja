import fs from 'node:fs';
import assert from 'node:assert/strict';
import { launchBrowser } from '../current/tests/helpers/browser.mjs';
import { scrollToInteractable } from '../current/tests/helpers/browser-interaction.mjs';
const records=[];
for(const mode of [true,false]){
 const browser=await launchBrowser({enforceWebSecurity:true,scrollEndEvents:mode});
 try{for(const [name,css,expected]of [
  ['own-opacity-zero','#target{opacity:0}','opacity'],
  ['oversized-outside-viewport','#target{width:500px}','viewport'],
  ['disabled-target','', 'disabled'],
  ['pointer-events-none','#target{pointer-events:none}','pointer-events'],
  ['real-no-scroll-page','',null],
  ['scroll-request-throws','', 'fixture-scroll-throws']
 ]){
  const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  try{
   await page.setViewport({width:390,height:844});await page.setContent('<!doctype html><style>html{scroll-behavior:smooth}body{margin:0;'+(name==='real-no-scroll-page'?'':'height:2500px;')+'}#target{display:block;position:absolute;left:0;top:'+(name==='real-no-scroll-page'?0:900)+'px;width:100px;height:34px;padding:0;border:0}'+css+'</style><button id="target" '+(name==='disabled-target'?'disabled':'')+'>Alvo</button>');
   await page.evaluate(throws=>{
    window.ends=[];document.addEventListener('scrollend',e=>ends.push({x:scrollX,y:scrollY,trusted:e.isTrusted}));
    const add=document.addEventListener.bind(document),remove=document.removeEventListener.bind(document),active=new Set();
    document.addEventListener=(type,fn,opts)=>{if(['scroll','scrollend'].includes(type))active.add(fn);return add(type,fn,opts);};
    document.removeEventListener=(type,fn,opts)=>{active.delete(fn);return remove(type,fn,opts);};window.active=()=>active.size;
    if(throws)document.getElementById('target').scrollIntoView=()=>{throw new Error('fixture-scroll-throws');};
   },name==='scroll-request-throws');
   const start=performance.now();let error;
   try{await scrollToInteractable(page,'#target');}catch(e){error=e;}
   if(expected==='fixture-scroll-throws')assert.match(error?.message||'',/fixture-scroll-throws/);
   else if(expected){assert.equal(error?.name,'TimeoutError');assert.match(error.message,/4000ms/);assert.equal(error.interaction?.reason,expected);assert.ok(performance.now()-start>=3900);}
   else assert.equal(error,undefined);
   const state=await page.evaluate(()=>{const e=document.getElementById('target'),b=e.getBoundingClientRect();return{position:[scrollX,scrollY],max:document.scrollingElement.scrollHeight-innerHeight,box:b.toJSON(),ownOpacity:getComputedStyle(e).opacity,active:active(),references:document.querySelectorAll('iframe').length,ends};});
   assert.equal(state.active,0);assert.equal(state.references,0);assert.deepEqual(errors,[]);
   if(name==='oversized-outside-viewport'){assert.ok(state.box.right>390);assert.equal(error.interaction.atDestination,true);assert.ok(error.interaction.stableFrames>=2);if(mode)assert.equal(error.interaction.nativeReceived,true);}
   if(name==='real-no-scroll-page'){assert.equal(state.max,0);assert.deepEqual(state.position,[0,0]);assert.equal(state.ends.length,0);}
   const record={mode:mode?'ON':'OFF',name,reason:error?.interaction?.reason||error?.message||'ready',elapsedMs:Math.round(performance.now()-start),diagnostic:error?.interaction,state,consoleErrors:errors.length};records.push(record);console.log('✅ SUPPLEMENTAL '+JSON.stringify(record));
  }finally{await page.close();}
 }}finally{await browser.close();}
}
fs.writeFileSync(new URL('../evidence/supplemental-checks.json',import.meta.url),JSON.stringify(records,null,2)+'\n');console.log('SUPPLEMENTAL '+records.length+'/'+records.length+' approved.');
