from pathlib import Path
import zipfile,json,hashlib,re
W=Path(__file__).resolve().parent.parent;root=Path('/home/user/forja');target=root/'docs/evidencias-helper-scroll-e2e.zip';sha=lambda b:hashlib.sha256(b).hexdigest()
entries={}
for group in ['logs','evidence','instruments']:
 for p in sorted((W/group).glob('*')):
  if p.is_file() and p.name not in ['index-before.bin','index-entries-before.bin','diff-before.patch','cached-diff-before.patch']:entries[f'{group}/{p.name}']=p
for variant in ['before','current','red-entry','mutant-visual-stability','mutant-margin-omitted']:
 for name in ['tests/helpers/browser-interaction.mjs','tests/browser-interaction.browser.mjs','tests/browser-interaction-regressions.browser.mjs','tests/helpers/browser.mjs','package.json','package-lock.json']:
  p=W/variant/name
  if p.is_file():entries[f'{variant}/{name}']=p
for name in ['docs/correcao-helper-scroll-e2e.md','docs/evidencias-helper-scroll-e2e.json']:
 entries[f'before/{name}']=W/'before'/name;entries[f'deliverables/{name}']=root/name
payload={name:p.read_bytes()for name,p in entries.items()}
# No runtime credentials enter this bundle. Refuse common real-secret shapes;
# all application services used by tests were isolated simulations.
secretShapes=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'gh[pousr]_[A-Za-z0-9]{25,}'),re.compile(rb'github_pat_[A-Za-z0-9_]{30,}'),re.compile(rb'sb_secret_[A-Za-z0-9_-]{15,}')]
violations=[name for name,b in payload.items()if any(pattern.search(b)for pattern in secretShapes)]
assert not violations,('Credential-like content refused; do not print values',violations)
manifest={name:sha(b)for name,b in payload.items()}
readme='''# FORJA — evidências da correção final do helper E2E\n\nPacote de documentação local, não autorização de envio/publicação. Todos os resultados são desta etapa, exceto os documentos em before/docs, explicitamente históricos.\n\n## Resultados finais\n\n- npm test: 498/498; Auth E2E: 71/71.\n- npm run test:e2e: 10/10 anteriores + 30/30 novos + 46/46 gerais.\n- Matriz reexecutada: 40/40; geral com ScrollEndEvents OFF: 46/46.\n- Cinco novas rodadas consecutivas: 18/18 + 23/23 cada.\n- Sintaxe:97/97; 589 asserts/46 cenários gerais intactos; 12/12 checks suplementares.\n- Helper de entrada exato e49c03…:6/30 -> corrigido:30/30, mesmos corpos finais.\n- Seis resultados já GREEN na entrada têm RED de sensibilidade por mutação SINTÉTICA explicitamente identificada. Caso15: RED de diagnóstico, não falta de bloqueio.\n- RED→GREEN histórico de Auth 141f2961…: NÃO VERIFICADO.\n\n## Conteúdo e confiança\n\n- before/: helper de entrada 3527 bytes/e49c03… e versões anteriores dos documentos (não baseline histórico Auth).\n- current/: helper/testes corrigidos, únicos aplicados. Contém somente os arquivos relevantes, NÃO a aplicação inteira.\n- red-entry/: mesmos testes finais e helper exato de entrada.\n- mutant-*/: helpers SINTÉTICOS deliberadamente defeituosos; nunca aplicados.\n- logs/: stdout/stderr brutos, metadados com hashes completos antes/depois e observadores. Falhas v1/v3 foram mantidas.\n- evidence/: manifests, diagnósticos/causas por caso, provas de capacidade/SOP/CORS, hashes, cinco rodadas e final-integrity.json.\n- instruments/: instrumentos realmente usados. Caminhos /tmp são os da execução original; um reuso offline deve adaptar caminhos locais sem confundir isso com bytes históricos.\n- deliverables/: relatório e JSON finais, byte-exatos ao checkout entregue.\n- MANIFEST.json: SHA-256 de cada payload. O manifesto e o ZIP não contêm o próprio hash recursivamente.\n\nVerifique todos os hashes do manifesto antes de usar evidências. Para repetir os testes use uma cópia isolada do checkout existente e os arquivos current; nenhum helper RED deve ser restaurado no checkout original. Não executar download remoto, SQL, stage/commit/push/merge/deploy/workflow ou acessar serviços reais sem autorização.\n\nO pacote não contém node_modules, .git/index/diffs, HOME, cache de dependências, binários do navegador, screenshots/downloads da aplicação ou dados/credenciais reais. Chromium e SDK oficial são reais; Google/Auth/PostgREST/RLS foram simulados. --no-sandbox não certifica sandbox do SO. As observações de rede não são packet capture.\n\nStorages totalmente indisponíveis + revogação503: bloqueio em memória NÃO é garantia de logout durável após reload;503 NÃO confirma revogação. Essa limitação não foi corrigida ou ocultada nesta tarefa.\n'''
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in payload.items():z.writestr(name,b)
 z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');z.writestr('README.md',readme)
with zipfile.ZipFile(target)as z:
 assert z.testzip()is None
 assert all(sha(z.read(n))==h for n,h in manifest.items())
 assert len(z.namelist())==len(set(z.namelist()))
 for name in ['docs/correcao-helper-scroll-e2e.md','docs/evidencias-helper-scroll-e2e.json']:
  assert z.read('deliverables/'+name)==(root/name).read_bytes()
 for name in ['tests/helpers/browser-interaction.mjs','tests/browser-interaction.browser.mjs','tests/browser-interaction-regressions.browser.mjs']:
  assert z.read('current/'+name)==(root/name).read_bytes()
 assert json.loads(z.read('evidence/final-integrity.json'))['ok']is True
 summary={'archive':str(target),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'entries':len(z.namelist()),'verifiedPayloadHashes':len(manifest),'crcOk':True,'deliverablesByteExact':True,'credentialPatternScanClean':True}
print(json.dumps(summary,ensure_ascii=False,indent=2))
