import fs from 'node:fs';
import http from 'node:http';
import assert from 'node:assert/strict';
import { launchBrowser } from '../current/tests/helpers/browser.mjs';
const W=new URL('../',import.meta.url),records=[];
const target=http.createServer((req,res)=>res.writeHead(200,{'content-type':'text/html','cache-control':'no-store'}).end('<!doctype html><p>Outra origem local, sem CORS.</p>'));
await new Promise(resolve=>target.listen(0,'0.0.0.0',resolve));const other='http://127.0.0.1:'+target.address().port;
const source=http.createServer((req,res)=>res.writeHead(200,{'content-type':'text/html','cache-control':'no-store'}).end('<!doctype html><iframe src="'+other+'/"></iframe>'));
await new Promise(resolve=>source.listen(0,'0.0.0.0',resolve));
try{for(const scrollEndEvents of [true,false]){
 const browser=await launchBrowser({enforceWebSecurity:true,scrollEndEvents});
 try{
  const page=await browser.newPage(),expectedConsole=[];page.on('console',m=>{if(m.type()==='error')expectedConsole.push(m.text());});
  await page.goto('http://127.0.0.1:'+source.address().port+'/',{waitUntil:'load'});
  const observed=await page.evaluate(async other=>{let sop,cors;try{void document.querySelector('iframe').contentWindow.document;sop='UNEXPECTED_READ';}catch(e){sop=e.name;}
   try{await fetch(other+'/no-cors');cors='UNEXPECTED_READ';}catch(e){cors=e.name;}return{sop,cors,nativeScrollend:'onscrollend'in document};},other);
  const session=await page.createCDPSession(),actual=await session.send('Browser.getBrowserCommandLine');
  const unsafe=actual.arguments.filter(a=>/^--(?:disable-web-security|allow-running-insecure-content|disable-site-isolation-trials)(?:=|$)/.test(a)||a.startsWith('--disable-features=')&&/(?:^|,)(?:IsolateOrigins|site-per-process)(?:,|$)/.test(a.split('=')[1]));
  assert.equal(observed.sop,'SecurityError');assert.equal(observed.cors,'TypeError');assert.equal(observed.nativeScrollend,scrollEndEvents);assert.deepEqual(unsafe,[]);
  records.push({scrollEndEvents,version:await browser.version(),observed,unsafe,actualBrowserArguments:actual.arguments,expectedCorsConsole:expectedConsole,note:'Expected CORS-denial console entries occur only in this deliberate local denial probe, not in the zero-error matrices. --no-sandbox does not attest OS sandboxing.'});console.log(JSON.stringify({scrollEndEvents,observed,unsafe}));
 }finally{await browser.close();}
}}finally{await Promise.all([new Promise(resolve=>source.close(resolve)),new Promise(resolve=>target.close(resolve))]);}
fs.writeFileSync(new URL('evidence/security-observation.json',W),JSON.stringify(records,null,2)+'\n');
