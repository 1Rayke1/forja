import pathlib,subprocess,os,sys,time,hashlib,json,signal
W=pathlib.Path(__file__).resolve().parent.parent;source=pathlib.Path('/home/user/forja');name=sys.argv[1];variant=sys.argv[2];command=sys.argv[3:];root=W/variant
base={'PATH':os.environ['PATH'],'HOME':str(W/'home'),'TMPDIR':str(W/'tmp'),'npm_config_cache':str(W/'npm-cache'),'npm_config_userconfig':'/dev/null','npm_config_update_notifier':'false','npm_config_offline':'true','GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','LANG':'C.UTF-8','TZ':'UTC','NODE_OPTIONS':'--require='+str(W/'instruments/readonly.cjs'),'FORJA_RUN_OBSERVER':str(W/'logs'/f'{name}.observer.jsonl')}
def snapshot(at):
 paths=subprocess.check_output(['git','--no-optional-locks','ls-files','--cached','--others','--exclude-standard','-z'],cwd=at,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).split(b'\0')
 return{os.fsdecode(p):hashlib.sha256((at/os.fsdecode(p)).read_bytes()).hexdigest()for p in paths if p and(at/os.fsdecode(p)).is_file()}
def fp(d):return hashlib.sha256(json.dumps(d,sort_keys=True,separators=(',',':')).encode()).hexdigest()
a=snapshot(root);s0=snapshot(source);start=time.monotonic();timeout=False
with(W/'logs'/f'{name}.log').open('w')as out:
 p=subprocess.Popen(command,cwd=root,env=base,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=p.wait(timeout=1450)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  rc=124
 elapsed=round(time.monotonic()-start,3);out.write(f'\nRUN exit={rc} seconds={elapsed} timeout={timeout}\n')
b=snapshot(root);s1=snapshot(source);changes=sorted(k for k in a.keys()|b.keys()if a.get(k)!=b.get(k));sourceChanges=sorted(k for k in s0.keys()|s1.keys()if s0.get(k)!=s1.get(k))
r={'name':name,'variant':variant,'command':command,'exit':rc,'seconds':elapsed,'timeout':timeout,'filesBefore':len(a),'beforeFingerprint':fp(a),'afterFingerprint':fp(b),'changedDuringRun':changes,'sourceBefore':fp(s0),'sourceAfter':fp(s1),'sourceChangesDuringRun':sourceChanges,'fileHashesBefore':a,'fileHashesAfter':b}
(W/'logs'/f'{name}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if not k.startswith('fileHashes')},ensure_ascii=False))
lines=(W/'logs'/f'{name}.log').read_text().splitlines()
for line in lines:
 if line.startswith(('✅ REGRESSION','❌ REGRESSION','SCROLL REGRESSIONS','SCROLL SYNC','❌')):print(line.split(' {')[0])
print('\n'.join(line[:900] for line in lines[-16:]));sys.exit(rc if not changes and not sourceChanges else 99)
