import fs from 'node:fs';
import assert from 'node:assert/strict';
import { launchBrowser } from '../current/tests/helpers/browser.mjs';
const browser=await launchBrowser({enforceWebSecurity:true});
try{
 const page=await browser.newPage();await page.goto('about:blank');
 const nativeScrollend=await page.evaluate(()=>'onscrollend'in document),session=await page.createCDPSession(),args=await session.send('Browser.getBrowserCommandLine');
 assert.equal(nativeScrollend,false);assert.ok(args.arguments.includes('--disable-blink-features=ScrollEndEvents'));
 const evidence={wrapper:process.env.PUPPETEER_EXECUTABLE_PATH,nativeScrollend,actualBrowserArguments:args.arguments,version:await browser.version(),note:'Same exact executable wrapper used by full-general-browser-off; separate capability observation, not a per-page instrument injected into the general suite.'};
 fs.writeFileSync(new URL('../evidence/general-off-wrapper-proof.json',import.meta.url),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence));
}finally{await browser.close();}
