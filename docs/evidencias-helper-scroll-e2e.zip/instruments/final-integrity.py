from pathlib import Path
import json,hashlib,subprocess,os,collections,sys
W=Path(__file__).resolve().parent.parent;root=Path('/home/user/forja');pre='--pre-docs'in sys.argv
sha=lambda b:hashlib.sha256(b).hexdigest()
def fp(d):return sha(json.dumps(d,sort_keys=True,separators=(',',':')).encode())
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=root,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
base=json.loads((W/'evidence/baseline.json').read_text());initial=json.loads((W/'evidence/initial-state.json').read_text())
paths=[os.fsdecode(p)for p in git('ls-files','--cached','--others','--exclude-standard','-z').split(b'\0')if p];after={p:sha((root/p).read_bytes())for p in paths if(root/p).is_file()}
modified=sorted(p for p in base if p in after and base[p]!=after[p]);added=sorted(set(after)-set(base));removed=sorted(set(base)-set(after))
code=['tests/helpers/browser-interaction.mjs','tests/browser-interaction.browser.mjs','tests/browser-interaction-regressions.browser.mjs'];reports=['docs/correcao-helper-scroll-e2e.md','docs/evidencias-helper-scroll-e2e.json'];archive='docs/evidencias-helper-scroll-e2e.zip';artifacts=set(reports+[archive])
allowedModified=set(code[:2]+reports);allowedAdded={code[2],archive};checks={}
checks['onlyAuthorizedChanges']=set(modified)<=allowedModified and set(added)==allowedAdded and not removed
if not pre:checks['allExpectedChangesPresent']=set(modified)==allowedModified
checks['codeEqualsExecutedCopy']=all((root/p).read_bytes()==(W/'current'/p).read_bytes()for p in code)
reference=json.loads((W/'logs/full-general-browser.json').read_text());nonartifacts={p:h for p,h in after.items()if p not in artifacts};executed={p:h for p,h in reference['fileHashesAfter'].items()if p not in artifacts}
checks['allNonArtifactBytesEqualExecutedTree']=nonartifacts==executed
checks['originalFileCount']=len(base)==811;checks['finalFileCount']=len(after)==813
index=(root/'.git/index').read_bytes();checks['indexByteIdentical']=index==(W/'evidence/index-before.bin').read_bytes()
commands={'branch-before.txt':['branch','--show-current'],'head-before.txt':['rev-parse','HEAD'],'reflog-before.txt':['reflog','--all','--format=%H %gD %gs'],'index-entries-before.bin':['ls-files','--stage','-z'],'diff-before.patch':['diff','--binary'],'cached-diff-before.patch':['diff','--cached','--binary']}
gitState={}
for name,args in commands.items():
 old=(W/'evidence'/name).read_bytes();now=git(*args);checks[name+'Identical']=now==old;gitState[name]={'command':['git',*args],'beforeSha256':sha(old),'afterSha256':sha(now),'identical':now==old}
checks['stageEmpty']=git('diff','--cached','--name-only')==b''
beforeStatus=(W/'evidence/status-before.txt').read_text().splitlines();status=git('status','--short','--untracked-files=all').decode().splitlines()
checks['preexistingStatusPreserved']=set(beforeStatus)<=set(status) and sorted(set(status)-set(beforeStatus))==sorted('?? '+p for p in allowedAdded)
checks['noNodeModulesInCheckout']=not(root/'node_modules').exists()
diffchecks=[]
for opts in [[],['--cached']]:
 p=subprocess.run(['git','--no-optional-locks','diff',*opts,'--check'],cwd=root,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},capture_output=True,text=True);diffchecks.append({'command':['git','diff',*opts,'--check'],'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
checks['diffCheck']=all(p['exit']==0 for p in diffchecks)
whitespace=[]
for p in code+reports:
 for i,l in enumerate((root/p).read_text().splitlines(),1):
  if l.rstrip(' \t')!=l or l.startswith(('<<<<<<<','=======','>>>>>>>')):whitespace.append({'path':p,'line':i})
checks['changedTextWhitespaceClean']=not whitespace
protectedPaths=['assets/js/forja-auth.js','assets/js/forja-login.js','assets/js/forja-auth-data.js','assets/js/forja-auth-guard.js','assets/vendor/supabase/supabase.js','tests/e2e.browser.mjs','tests/helpers/browser.mjs','package.json','package-lock.json']
protected={p:{'beforeSha256':base[p],'afterSha256':after[p],'identical':base[p]==after[p]}for p in protectedPaths};checks['protectedFilesIdentical']=all(r['identical']for r in protected.values())
metadata=[]
for p in sorted((W/'logs').glob('*.json')):
 r=json.loads(p.read_text())
 if 'changedDuringRun'in r:metadata.append({'name':r['name'],'exit':r['exit'],'changedDuringRun':r['changedDuringRun'],'sourceChangesDuringRun':r['sourceChangesDuringRun']})
checks['noTestRunChangedAnySource']=all(not r['changedDuringRun']and not r['sourceChangesDuringRun']for r in metadata)
observations=[];launches=[]
for p in sorted((W/'logs').glob('*.observer.jsonl')):
 for l in p.read_text().splitlines():
  r=json.loads(l)
  if 'chromiumCommand'in r:launches.append({'log':p.name,**r})
  if any(k in r for k in ['blockedNetwork','blockedTcp','blockedCommand','deniedWrite']):observations.append({'log':p.name,**r})
checks['noDeniedMutationOrExternalNodeRequest']=not observations;checks['noUnsafeBrowserFlags']=all(r.get('unsafe')==[]for r in launches)
concurrency=json.loads((W/'evidence/concurrency-five-rounds.json').read_text());checks['fiveNewConsecutiveRounds']=concurrency['allFiveComplete']and concurrency['allPassed']and concurrency['sequential']and len(concurrency['rounds'])==5
static=json.loads((W/'evidence/static-final-code.json').read_text());checks['syntaxAndOriginalAssertions']=static['ok']and static['syntax']['files']==97 and static['generalE2E']['asserts']==589 and static['generalE2E']['scenarios']==46
required=['green-regressions-final','full-unit','full-auth-browser','full-general-browser','static-final-code','vendor-check','security-observation','final-scroll-matrix','supplemental-checks','full-general-browser-off','general-off-wrapper-proof']+['concurrency-round-'+str(i)for i in range(1,6)]
checks['requiredAndAdditionalGreen']=all(json.loads((W/'logs'/f'{n}.json').read_text())['exit']==0 for n in required)
if not pre:
 document=json.loads((root/reports[1]).read_text());checks['finalJsonSchema']=document.get('schemaVersion')==2
 checks['finalJsonReportHash']=document['files'][reports[0]]['afterSha256']==after[reports[0]]
 checks['finalJsonCodeHashes']=all(document['files'][p]['afterSha256']==after[p]for p in code)
 checks['finalJsonAllRequiredGreen']=document['result']['allRequiredLocalChecksPassed'] is True and document['historicalAuthCounterfactual']['verified'] is False
result={'phase':'pre-docs'if pre else'final','ok':all(checks.values()),'checks':checks,'baseline':{'files':len(base),'fingerprint':fp(base)},'final':{'files':len(after),'originalFilesUnchanged':sum(after.get(p)==h for p,h in base.items()),'modifiedExisting':modified,'added':added,'removed':removed,'nonArtifactFiles':len(nonartifacts),'nonArtifactFingerprint':fp(nonartifacts),'fingerprintExcludingArchive':fp({p:h for p,h in after.items()if p!=archive}),'fullFingerprintDeliberatelyOmitted':'The evidence archive cannot include its own final SHA-256. Archive payload hashes are in MANIFEST.json; the final outer hash is printed after packaging.','trackedModifiedBefore':sum(not l.startswith('??')for l in beforeStatus),'trackedModifiedAfter':sum(not l.startswith('??')for l in status),'untrackedBefore':sum(l.startswith('??')for l in beforeStatus),'untrackedAfter':sum(l.startswith('??')for l in status),'stageEmpty':checks['stageEmpty']},'git':{'indexBeforeSha256':initial['indexSha256'],'indexAfterSha256':sha(index),'records':gitState,'diffChecks':diffchecks},'protected':protected,'nonArtifactManifest':nonartifacts,'reportHashes':{p:after[p]for p in reports},'statusAfter':status,'testRuns':metadata,'observer':{'launches':len(launches),'modesInNodeArgv':dict(collections.Counter('OFF'if '--disable-blink-features=ScrollEndEvents'in r['argv']else'ON'if '--enable-blink-features=ScrollEndEvents'in r['argv']else'OFF-wrapper'if'no-scrollend'in r['chromiumCommand']else'default'for r in launches)),'unsafe':sum(bool(r['unsafe'])for r in launches),'denied':observations,'note':'Mode capabilities separately asserted in browser/security probes. This is not an OS sandbox certificate or a network packet capture.'},'whitespace':whitespace}
(W/'evidence'/('pre-docs-integrity.json'if pre else'final-integrity.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k in ['phase','ok','checks','baseline','final','observer']},ensure_ascii=False,indent=2))
if not result['ok']:raise SystemExit(1)
