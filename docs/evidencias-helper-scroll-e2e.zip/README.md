# FORJA — evidências da correção final do helper E2E

Pacote de documentação local, não autorização de envio/publicação. Todos os resultados são desta etapa, exceto os documentos em before/docs, explicitamente históricos.

## Resultados finais

- npm test: 498/498; Auth E2E: 71/71.
- npm run test:e2e: 10/10 anteriores + 30/30 novos + 46/46 gerais.
- Matriz reexecutada: 40/40; geral com ScrollEndEvents OFF: 46/46.
- Cinco novas rodadas consecutivas: 18/18 + 23/23 cada.
- Sintaxe:97/97; 589 asserts/46 cenários gerais intactos; 12/12 checks suplementares.
- Helper de entrada exato e49c03…:6/30 -> corrigido:30/30, mesmos corpos finais.
- Seis resultados já GREEN na entrada têm RED de sensibilidade por mutação SINTÉTICA explicitamente identificada. Caso15: RED de diagnóstico, não falta de bloqueio.
- RED→GREEN histórico de Auth 141f2961…: NÃO VERIFICADO.

## Conteúdo e confiança

- before/: helper de entrada 3527 bytes/e49c03… e versões anteriores dos documentos (não baseline histórico Auth).
- current/: helper/testes corrigidos, únicos aplicados. Contém somente os arquivos relevantes, NÃO a aplicação inteira.
- red-entry/: mesmos testes finais e helper exato de entrada.
- mutant-*/: helpers SINTÉTICOS deliberadamente defeituosos; nunca aplicados.
- logs/: stdout/stderr brutos, metadados com hashes completos antes/depois e observadores. Falhas v1/v3 foram mantidas.
- evidence/: manifests, diagnósticos/causas por caso, provas de capacidade/SOP/CORS, hashes, cinco rodadas e final-integrity.json.
- instruments/: instrumentos realmente usados. Caminhos /tmp são os da execução original; um reuso offline deve adaptar caminhos locais sem confundir isso com bytes históricos.
- deliverables/: relatório e JSON finais, byte-exatos ao checkout entregue.
- MANIFEST.json: SHA-256 de cada payload. O manifesto e o ZIP não contêm o próprio hash recursivamente.

Verifique todos os hashes do manifesto antes de usar evidências. Para repetir os testes use uma cópia isolada do checkout existente e os arquivos current; nenhum helper RED deve ser restaurado no checkout original. Não executar download remoto, SQL, stage/commit/push/merge/deploy/workflow ou acessar serviços reais sem autorização.

O pacote não contém node_modules, .git/index/diffs, HOME, cache de dependências, binários do navegador, screenshots/downloads da aplicação ou dados/credenciais reais. Chromium e SDK oficial são reais; Google/Auth/PostgREST/RLS foram simulados. --no-sandbox não certifica sandbox do SO. As observações de rede não são packet capture.

Storages totalmente indisponíveis + revogação503: bloqueio em memória NÃO é garantia de logout durável após reload;503 NÃO confirma revogação. Essa limitação não foi corrigida ou ocultada nesta tarefa.
