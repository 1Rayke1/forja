# Correção final do helper E2E — PR #71, somente local

**Resultado: helper validado com `ScrollEndEvents` ON e OFF, sem timeout inesperado.** As suítes obrigatórias e cinco rodadas consecutivas de concorrência passaram. O RED→GREEN do **helper de scroll** foi reproduzido nesta execução. O baseline histórico de **Auth** `141f2961…` continua **NÃO VERIFICADO**, pois seus bytes não foram recuperados. Não confundir essas duas evidências.

Branch `arena/468b7e01-forja`; HEAD/base `99cffc9147d72cc4eedd2eaf47310fc135815c3b`. Autorização restrita a correções/testes locais. Nenhum stage, commit, push, alteração do PR, merge, deploy/retry, workflow, SQL, conta/credencial real ou configuração externa. As únicas consultas remotas foram GETs de metadados do PR/main; nenhuma versão de Auth foi baixada como substituta.

## 1. Causa do timeout e RED preservado

O helper anterior sempre registrava `scrollend` e, quando precisava deslocar, só esse evento mudava `done` para true. Aceitar `addEventListener('scrollend', ...)` não comprova suporte: nomes desconhecidos também são aceitos. Com a implementação Blink desabilitada, `onscrollend` está ausente e a condição expira em 4 s.

- Guard original/Chromium padrão: **1/1**, exit 0, 1,277 s.
- Guard original com `--disable-blink-features=ScrollEndEvents`: **exit 1**, `TimeoutError: Waiting failed: 4000ms exceeded`, 4,530 s.
- Mesmos corpos finais dos testes, mas helper original: **7/10**, exit 1, 26,812 s. OFF 1/2 expiram; ON 2 também demonstra conclusão prematura ao receber um evento intermediário durante uma pausa fora do destino.
- Substituir **somente** o helper pelo corrigido: **10/10**, exit 0, 20,341 s. SHA do teste/harness iguais entre esse RED e GREEN; nenhum assert foi enfraquecido depois do RED.

O JSON acompanhante guarda o helper original exato (2.264 bytes) em base64, hash `e529959361d81568edbaaad30fe1c3f5439afac8dd63bf6b4a873ba4616d7e1c`. Assim o contrafactual de scroll pode ser reproduzido em cópia isolada mesmo se o cache desaparecer. Nunca restaurar esse helper defeituoso no checkout de trabalho.

## 2. Implementação e justificativa técnica

`tests/helpers/browser-interaction.mjs` detecta **`'onscrollend' in document`**. Havendo suporte, registra o listener antes do pedido e continua exigindo o evento nativo; apenas eventos no documento/root e já no destino solicitado podem concluí-lo. Se não há deslocamento necessário, não se espera um evento que o navegador não precisa emitir.

Sem suporte, o fallback exige cumulativamente:

1. Chegar ao destino centralizado/clampado da rolagem do documento, com tolerância inferior a 1 CSS px para arredondamento.
2. Posição real `scrollTop`/`scrollLeft` e geometria do alvo idênticas em **três amostras de `requestAnimationFrame`**, ou dois intervalos estáveis.
3. Elemento conectado/habilitado, visível, inteiro no viewport e livre no `elementFromPoint`.

Estabilidade sozinha não basta: uma posição parada antes de começar ou numa pausa intermediária **fora do destino** não libera a interação. Com suporte nativo, estabilidade/destino também não dispensam `scrollend`. O prazo continua **4.000 ms**; timeout/erro também limpam listener e handle. O chamador usa `page.click`, não `element.click`/evento de clique sintético.

**Por que esta API:** `scrollend` é a indicação nativa apropriada. `scrollIntoView()` não fornece uma Promise de conclusão, e observar apenas interseção/hit-test ou um atraso fixo não prova fim da rolagem. No ramo sem evento, rAF observa estado efetivamente renderizado, sem escolher uma duração presumida de animação. Não foi adicionado `sleep(180)` nem outro sleep. Os seis frames usados para desafiar a barreira no teste são oportunidades de renderização **enquanto o pedido permanece retido**, não a condição de conclusão do helper.

O parâmetro opcional `scrollEndEvents` em `tests/helpers/browser.mjs` altera só esse recurso Blink nos testes. Sem o parâmetro, o comportamento das demais suítes permanece o padrão. Nenhum código de produção/Auth foi alterado.

## 3. Mesmos cenários com evento ligado e desligado

Chromium **138.0.7204.0** real; SDK oficial **2.119.0**; serviços Google/Auth/PostgREST/RLS fictícios. A propriedade do navegador é afirmada em cada cenário, não apenas simulada no JavaScript do helper.

| Verificação | ON | OFF |
|---|---|---|
| Pedido retido e alvo inicialmente obstruído | não libera | não libera |
| Alvo já livre, mas scroll ainda não começou | não libera | não libera |
| Posição parada/evento intermediário fora do destino | não libera | não libera |
| Rolagem suave real até o destino | passa | passa |
| Estado final no cenário original | scrollY 377; top 405; hit BUTTON | scrollY 377; top 405; hit BUTTON |
| Cenário com pausa intermediária | scrollY 245; top 405 | scrollY 245; top 405 |
| Sem deslocamento necessário | passa sem esperar evento | passa sem esperar evento |
| Visibilidade, hit-test e clique real `isTrusted=true` | passa | passa |
| Erros de console/página nos cinco cenários | 0 | 0 |
| Total da matriz | **5/5** | **5/5** |

Os cenários negativos (pedido que nunca progride e alvo ainda coberto no destino) **passam ao afirmar o TimeoutError original de 4 s**, sem clicar e sem vazar listener. Não são timeouts inesperados dos cenários positivos. A instrumentação apenas retém a entrega de eventos nativos reais (`isTrusted` afirmado), sem criar/redisparar `scrollend`.

SOP/CORS foram observados também nos dois modos: acesso DOM entre origens → `SecurityError`; fetch sem CORS → `TypeError`. Não se usou `--disable-web-security`, nem desativação de `IsolateOrigins`/`site-per-process`. O pacote headless usa `--no-sandbox`; isso não é certificado de sandbox do SO nem de todas as propriedades de isolamento.

## 4. Suítes completas desta execução

| Comando | Resultado | Exit | Duração |
|---|---|---:|---:|
| `npm test` | **498/498** | 0 | 1055,085 s |
| `npm run test:auth:e2e` | **71/71** (29 + 19 + 23) | 0 | 325,531 s |
| `npm run test:e2e` | **10/10 scroll + 46/46 geral** | 0 | 877,818 s |
| `node tests/e2e.browser.mjs`, launcher com ScrollEndEvents OFF | **46/46 geral** | 0 | 822,309 s |
| Verificações de sintaxe | **96/96** arquivos | 0 | — |
| `git diff --check` | sem erros | 0 | — |
| `npm run vendor:supabase -- --check` | distribuição/licença/hash corretos | 0 | 0,221 s |

As suítes independentes foram executadas em paralelo em ambiente de 2 CPUs; durações não são benchmark. As cinco rodadas abaixo são consecutivas entre si e não houve alteração de código durante as execuções. O handler YouTube imprime um 500 esperado no teste negativo; não é erro inesperado do cenário do helper, que afirma zero erros de console/página.

**Preservação:** `tests/e2e.browser.mjs` permaneceu byte a byte igual à entrada. A inspeção AST confirmou **46 nomes e 589 chamadas de assert**, mesmos textos/ordem, nenhum novo skip/only. `package.json`/lockfile e todas as suítes/helpers de Auth, salvo o launcher genérico de navegador descrito, foram preservados. Não houve falha intermediária nas suítes obrigatórias; as falhas RED acima foram registradas antes da correção do helper.

## 5. Cinco rodadas consecutivas de concorrência

| Rodada | Unitários | Chromium | Exit | Duração |
|---:|---:|---:|---:|---:|
| 1 | 18/18 | 23/23 | 0 | 151,390 s |
| 2 | 18/18 | 23/23 | 0 | 144,813 s |
| 3 | 18/18 | 23/23 | 0 | 164,069 s |
| 4 | 18/18 | 23/23 | 0 | 101,516 s |
| 5 | 18/18 | 23/23 | 0 | 68,320 s |

Os casos de refresh/cleanup sob Web Lock, mesmo UID/nova sessão, BroadcastChannel/OAuth, PKCE, contas/UID, guards e storage/503 continuam passando. Os bytes do Auth não foram modificados para obter esses resultados.

## 6. Baseline histórico de Auth — NÃO VERIFICADO

Alvo exato: `141f2961b3fedc08ab4abdfe320b7ddaaf3b9001c1b7b1e7ce783aeae03cc201`.

Busca somente local, antes de gerar os novos artefatos: **812 objetos Git, 758 blobs**, incluindo não alcançáveis; `git fsck --full --no-reflogs --unreachable` exit 0. Também foram hasheados **882 arquivos** sob `/home/user` e `/tmp` (aproximadamente 90 MB), sem seguir symlinks e excluindo a área de trabalho nova; **nenhum arquivo de backup compactado foi encontrado**. A árvore `.git` foi examinada como objetos, não por hash do pack bruto. Não houve erros de leitura.

Ausentes: `/tmp/forja-final-fixes-gtygc81v`, `/tmp/forja-last-races-pl0g62au`, `/tmp/forja-readonly-final-mkzk34sg`, `/tmp/forja-independent-auth-ynn39i7_`, `.cache/auditoria-auth-final` e `.cache/correcao-concorrencia-auth`.

Foram encontradas somente referências textuais ao hash em três documentos anteriores, não os bytes do runtime. O histórico local visível não fornece a revisão desejada. **Não foi baixada, reconstruída ou inventada uma versão substituta.** Resumos históricos/hashes não permitem executar o runtime ausente; por isso não é possível certificar o RED→GREEN histórico de Auth nesta etapa. O GREEN atual foi reexecutado, mas não substitui esse contrafactual.

## 7. Arquivos alterados nesta tarefa

Somente **3 arquivos existentes alterados** e **2 documentos de evidência novos**; nenhum removido:

- `tests/helpers/browser-interaction.mjs` — detecção, fim nativo condicionado, fallback por destino/estado estável, mesmo limite/hit-test.
- `tests/helpers/browser.mjs` — opção Blink ON/OFF exclusiva do harness, sem mudar o padrão.
- `tests/browser-interaction.browser.mjs` — matriz de cinco cenários por configuração, cliques reais, console e limites negativos.
- `docs/correcao-helper-scroll-e2e.md` — este relatório.
- `docs/evidencias-helper-scroll-e2e.json` — resultados, hashes, busca local e baseline exato do helper de scroll.

| Arquivo | SHA-256 antes | SHA-256 depois |
|---|---|---|
| `tests/helpers/browser-interaction.mjs` | `e529959361d81568edbaaad30fe1c3f5439afac8dd63bf6b4a873ba4616d7e1c` | `e49c03e4680ab2b5930fc86c2bcba04d8700d87c4bceb184e3da6a52abb712fb` |
| `tests/helpers/browser.mjs` | `25d3f2cc9530257a89e5a68d701312c7eb1029d379caf3d05d7716d6e81faba8` | `7e24e50a79451187f32ce0b50c1ce527ebe3860d7d8feed1839671379b4e9fcb` |
| `tests/browser-interaction.browser.mjs` | `79110bc55c61a2ba85fcc2ac0d3fb5117515853c905d0f6f8d8e5f88b8a6a3eb` | `396a240fc8420cd381d5bbbf1df81a8f23055574d3b039712917d26a6fc63a85` |

## 8. Hashes, integridade e estado remoto

Entrada: **809 arquivos**, 43 modificados rastreados + 36 não rastreados, stage vazio. Após os dois relatórios: **811 arquivos**, os mesmos 43 modificados rastreados + 38 não rastreados. Dos 809 da entrada, **806 permanecem idênticos** e somente os três acima mudaram. O manifesto integral final fica no cache de evidências, fora destes relatórios autorreferentes.

```text
Fingerprint de entrada (809 arquivos):
f733dcb183cd9debd6e8fbfa1c8662641758f06f6787ffe126972ba414d3c19f
Fingerprint da árvore de código/testes executada (809 arquivos; relatórios ainda não adicionados):
8ad955076a3995e06e9d48929f09ca36dd55a7ef638847286000d05c6d28f938
SHA-256 do índice Git, antes = depois:
27ddc9190a09c30497f0de193b444749fafc4bf8a5e80468a1813b3932b8aace
Auth, antes = depois:
ebc0716a7dfaec4266113460ded8764402652b4a048df41710f139f8a1843ef8
SDK oficial, antes = depois:
a867edbcfb029370aeec7223dd6180b560b621fbe3bc64c6584fb0369d1b7bce
E2E geral, antes = depois:
b893e002f3a5a4922f62985b002959073271fbe9c38ce7f958dc4fd976f6ae4f
```

HEAD, branch, reflogs, entradas staged/índice e diff tracked/cached permaneceram iguais à entrada. Como os três arquivos de teste já eram não rastreados, o manifesto/hash complementa o `git diff`, que sozinho não mostraria esse delta. Nenhum arquivo fora da lista permitida foi alterado. Dependências foram instaladas só em cópia isolada (`npm ci --ignore-scripts`); não há `node_modules` no checkout.

GETs antes/depois: **PR #71 aberto/draft**, head `15c531e0b6a6a209c548cfa172b9ee313188c9ef`, updatedAt `2026-11-15T22:21:07Z`; **main** `99cffc9147d72cc4eedd2eaf47310fc135815c3b`, árvore `def2308dc6c15f9d46c153c1942e9ea5a5716660`, sem mudança. O PR não recebeu as correções locais. Não houve ação de stage/commit/push/merge/deploy/workflow nem mutação de PR/serviço.

Evidências completas em `/tmp/forja-scroll-final-hfxffpju` e cópia ignorada `.cache/correcao-helper-scroll-e2e/`, incluindo `evidencias-helper-scroll-e2e.zip` (sem dependências, Git objects, screenshots ou dados reais). `/tmp`/cache podem desaparecer entre ambientes: os resultados essenciais e bytes do helper anterior estão preservados neste relatório/JSON, sem depender deles.

## 9. Riscos restantes e conclusão

- **Baseline histórico de Auth ausente:** RED→GREEN de Auth continua NÃO VERIFICADO; não é apresentado como comprovado pelo conserto do scroll.
- Google/Supabase/RLS reais não foram homologados. Mobile emulado não é aparelho/Safari real. Nenhum SQL/credencial real foi usado.
- Falha total de ambos os storages + revogação 503 continua sem garantia de logout durável após reload antes do retry. O bloqueio imediato, aviso e retry existentes foram preservados, sem classificar essa limitação como resolvida.
- O helper é validado no fluxo atual de rolagem do documento; não há certificação de todos os scrollers aninhados, CSS scroll-snap, iframes ou engines. Se um scroll suportado não concluir/emitir seu evento, a condição falha no limite original, em vez de fingir sucesso.
- Nenhuma não conformidade backend fora de escopo foi corrigida/aprovada; o log do deploy falho anterior continua pendente, sem nova tentativa ou atribuição de causa.

**Conclusão:** o defeito local do helper foi corrigido e as duas configurações passaram, inclusive a suíte geral completa com o recurso desligado. Não é homologação real de Auth, aprovação para merge/publicação ou autorização para enviar o trabalho. **Aguardar autorização; não enviar ao PR.**
