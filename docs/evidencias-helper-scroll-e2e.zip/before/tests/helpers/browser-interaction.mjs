/* Sincronização E2E, não alteração do scroll/design de produção. */
export async function scrollToInteractable(page, selector) {
  const scrolling = await page.evaluateHandle(selector => {
    const element = document.querySelector(selector);
    if (!element) throw new Error('Alvo de rolagem ausente: ' + selector);
    const root = document.scrollingElement, box = element.getBoundingClientRect();
    const target = Math.max(0, Math.min(root.scrollHeight - innerHeight, root.scrollTop + box.top + box.height / 2 - innerHeight / 2));
    // Detectar a capacidade do documento, não apenas aceitar addEventListener:
    // navegadores sem o evento também aceitam nomes de eventos desconhecidos.
    const nativeEnd = 'onscrollend' in document;
    const state = { nativeEnd, ended: Math.abs(root.scrollTop - target) < 1, target, previous: null, stableFrames: 0 };
    const finish = event => {
      // Um scrollend de outra rolagem/pausa não conclui o pedido atual.
      if ((event.target === document || event.target === root) && Math.abs(root.scrollTop - target) < 1) state.ended = true;
    };
    if (nativeEnd) document.addEventListener('scrollend', finish, true);
    state.cleanup = () => { if (nativeEnd) document.removeEventListener('scrollend', finish, true); };
    // Registrar ANTES do pedido: a animação pode nem ter começado quando o
    // CDP retorna. O caso sem deslocamento não deve esperar um evento ausente.
    try { element.scrollIntoView({ block: 'center' }); }
    catch (error) { state.cleanup(); throw error; }
    return state;
  }, selector);
  try {
    await page.waitForFunction((selector, scrolling) => {
      const element = document.querySelector(selector);
      if (!element?.isConnected || element.matches(':disabled')) return false;
      const root = document.scrollingElement, box = element.getBoundingClientRect();
      const position = [root.scrollTop, root.scrollLeft, box.top, box.left, box.width, box.height];
      const same = scrolling.previous?.every((value, index) => value === position[index]);
      scrolling.previous = position;
      if (Math.abs(root.scrollTop - scrolling.target) >= 1) {
        scrolling.ended = false; scrolling.stableFrames = 0; return false;
      }
      // Sem scrollend não existe Promise nativa de scrollIntoView. Exigir o
      // DESTINO + três amostras iguais em rAF (dois intervalos estáveis), nunca
      // só um alvo livre/uma pausa antes do início ou no meio da animação.
      // Com suporte, a mesma estabilidade não dispensa o evento nativo.
      scrolling.stableFrames = same ? scrolling.stableFrames + 1 : 0;
      if (scrolling.stableFrames < 2 || (scrolling.nativeEnd && !scrolling.ended)) return false;
      const style = getComputedStyle(element);
      if (style.visibility !== 'visible' || style.pointerEvents === 'none' || Number(style.opacity) === 0 ||
          box.width <= 0 || box.height <= 0 || box.top < 0 || box.left < 0 || box.bottom > innerHeight || box.right > innerWidth) return false;
      const top = document.elementFromPoint(box.left + box.width / 2, box.top + box.height / 2);
      return top === element || element.contains(top);
    }, { polling: 'raf', timeout: 4000 }, selector, scrolling);
  } finally {
    // Mesmo limite de 4 s: falha explícita se o scroll não progride ou o alvo
    // continua obstruído. Limpar listener/handle também em erro/timeout.
    await scrolling.evaluate(state => state.cleanup()).catch(() => {});
    await scrolling.dispose();
  }
}
