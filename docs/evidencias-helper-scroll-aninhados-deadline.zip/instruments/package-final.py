from pathlib import Path
import hashlib,json,os,re,subprocess,zipfile
root=Path('/home/user/forja');W=root/'.cache/scroll-chain-deadline-20261115';sha=lambda b:hashlib.sha256(b).hexdigest();stem='evidencias-helper-scroll-aninhados-deadline';archive=root/'docs'/f'{stem}.zip';sums=root/'docs'/f'{stem}.sha256';report=root/'docs/correcao-helper-scroll-aninhados-deadline.md';machine=root/'docs'/f'{stem}.json'
assert not archive.exists()and not sums.exists(),'Refusing overwrite';payload={}
files=json.loads((W/'versions/v9-preserve-end-proof/freeze.json').read_text())
for p,h in files.items():
 b=(root/p).read_bytes();assert sha(b)==h;p2='current/'+p;payload[p2]=b
payload['entry/tests/helpers/browser-interaction.mjs']=(W/'entry/tests/helpers/browser-interaction.mjs').read_bytes();assert sha(payload['entry/tests/helpers/browser-interaction.mjs'])=='251191203b1462c01d3b6108fa4b6d15b36e86eae162ba99339c75adcda7ef62'
for folder in ['versions','logs','evidence','instruments']:
 for p in sorted((W/folder).rglob('*')):
  if p.is_file():payload[str(p.relative_to(W))]=p.read_bytes()
for p in [report,machine]:payload['deliverables/'+str(p.relative_to(root))]=p.read_bytes()
# Only directly relevant unchanged source is copied; all 813 entry files have
# hashes in evidence/baseline.json. Credentials and .git/config are never read.
for p in ['tests/helpers/browser.mjs','tests/e2e.browser.mjs','tests/browser-interaction.browser.mjs','tests/browser-interaction-regressions.browser.mjs','package.json','package-lock.json']:
 payload['unchanged/'+p]=(root/p).read_bytes()
for name,b in payload.items():
 assert not name.startswith('/')and'..'not in Path(name).parts
 if name.endswith(('.mjs','.js','.cjs','.json','.txt','.md','.log','.patch','.py')):
  assert not re.search(rb'(?:-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|sb_secret_[A-Za-z0-9]{12,}|gh[pousr]_[A-Za-z0-9]{25,}|AKIA[0-9A-Z]{16}|sk_live_[A-Za-z0-9]{12,})',b),'Potential secret marker at '+name
manifest={'schema':1,'algorithm':'SHA-256','scope':'Self-consistency of local captured evidence, not third-party execution attestation','excludes':['manifest.json','SHA256SUMS'],'entries':{p:{'bytes':len(b),'sha256':sha(b)}for p,b in sorted(payload.items())}}
payload['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();payload['SHA256SUMS']=(''.join(f'{sha(b)}  {p}\n'for p,b in sorted(payload.items()))).encode()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,b in sorted(payload.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,11,15,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b,compresslevel=9)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None;assert len(z.namelist())==len(set(z.namelist()))==len(payload)
 for name,b in payload.items():assert z.read(name)==b,name
 for name,item in manifest['entries'].items():assert sha(z.read(name))==item['sha256']
assert sha((root/'.git/index').read_bytes())=='933ebc5aab05c88b2e0b2a0e12e257762957e9023935421edf75948b1873e5b3'
tracked=subprocess.check_output(['git','--no-optional-locks','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});tree={os.fsdecode(p):sha((root/os.fsdecode(p)).read_bytes())for p in tracked.split(b'\0')if p and(root/os.fsdecode(p)).is_file()};fp=sha(json.dumps(tree,sort_keys=True,separators=(',',':')).encode());index=sha((root/'.git/index').read_bytes())
checks={str(p.relative_to(root)):sha(p.read_bytes())for p in [report,machine,archive]};checks.update(files)
text='# SHA-256; paths relative to repository root. This checksum file is not self-hashed.\n'+f'# Branch arena/468b7e01-forja; HEAD 99cffc9147d72cc4eedd2eaf47310fc135815c3b\n# Physical index SHA256 {index}\n# Whole-tree fingerprint excluding this checksum file: {fp}; files={len(tree)}\n'+f'# ZIP entries={len(payload)}; manifested payloads={len(manifest["entries"])}; CRC and every payload hash verified\n'+''.join(f'{h}  {p}\n'for p,h in sorted(checks.items()))
sums.write_text(text)
for p,h in checks.items():assert sha((root/p).read_bytes())==h,p
result={'zip':str(archive.relative_to(root)),'zipBytes':archive.stat().st_size,'zipSha256':sha(archive.read_bytes()),'entries':len(payload),'manifestedPayloads':len(manifest['entries']),'crcOk':True,'allInternalHashesOk':True,'entryHelperExact':True,'finalCodeFilesByteExact':True,'outerSha256File':str(sums.relative_to(root)),'outerSha256FileHash':sha(sums.read_bytes()),'treeBeforeChecksumFiles':len(tree),'treeBeforeChecksumFingerprint':fp,'physicalIndexSha256':index}
(W/'package-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
