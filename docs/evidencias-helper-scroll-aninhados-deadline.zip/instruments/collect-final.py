from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/home/user/forja');W=root/'.cache/scroll-chain-deadline-20261115';E=W/'evidence';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-optional-locks','-c','core.fsmonitor=false','-c','core.untrackedCache=false',*args],cwd=root,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
base=json.loads((E/'baseline.json').read_text());paths=[os.fsdecode(p)for p in git('ls-files','--cached','--others','--exclude-standard','-z').split(b'\0')if p];current={p:sha((root/p).read_bytes())for p in paths if(root/p).is_file()};changed={p:{'before':h,'after':current.get(p)}for p,h in base.items()if current.get(p)!=h};added={p:h for p,h in current.items()if p not in base}
initial=json.loads((E/'initial-state.json').read_text());integrity={'scope':'Final code tree BEFORE the four new documentation/evidence deliverables','files':len(current),'fingerprint':sha(json.dumps(current,sort_keys=True,separators=(',',':')).encode()),'changedEntryFiles':changed,'addedCodeFiles':added,'identicalEntryFiles':sum(current.get(p)==h for p,h in base.items()),'indexPhysicalSha256':sha((root/'.git/index').read_bytes()),'indexPhysicalPreservedSinceThisTaskEntry':sha((root/'.git/index').read_bytes())==initial['indexSha256'],'branch':git('branch','--show-current').decode().strip(),'head':git('rev-parse','HEAD').decode().strip(),'stagedEntriesIdentical':git('ls-files','--stage','-z')==(E/'staged-entries-before.bin').read_bytes(),'trackedDiffIdentical':git('diff','--binary')==(E/'diff-before.patch').read_bytes(),'cachedDiffIdentical':git('diff','--cached','--binary')==(E/'cached-diff-before.patch').read_bytes(),'reflogIdentical':git('reflog','--all','--format=%H %gD %gs')==(E/'reflog-before.txt').read_bytes(),'protected':{p:{'sha256':current[p],'identical':current[p]==h}for p,h in initial['protected'].items()if p!='tests/helpers/browser-interaction.mjs'}}
for name,args in [('status-code-final.txt',['status','--short','--untracked-files=all']),('head-code-final.txt',['rev-parse','HEAD']),('branch-code-final.txt',['branch','--show-current'])]:(E/name).write_bytes(git(*args))
assert set(changed)=={'tests/helpers/browser-interaction.mjs'};assert len(added)==8;assert integrity['identicalEntryFiles']==812;assert all(integrity[k]for k in ['indexPhysicalPreservedSinceThisTaskEntry','stagedEntriesIdentical','trackedDiffIdentical','cachedDiffIdentical','reflogIdentical']);assert integrity['branch']=='arena/468b7e01-forja';assert integrity['head']==initial['head']
(E/'code-integrity-v9.json').write_text(json.dumps(integrity,indent=2)+'\n')
def parse(name,prefix):
 lines=(W/'logs'/f'{name}.log').read_text().splitlines();out=[];item=None
 for line in lines:
  if line.startswith(('✅ '+prefix+' ','❌ '+prefix+' ')):
   body=line[2+len(prefix)+1:];key=body.split(' {',1)[0];item={'case':key,'passed':line.startswith('✅'),'run':name,'data':None};out.append(item)
   if item['passed']and' {'in body:item['data']=json.loads(body[body.index(' {')+1:])
  elif item and line.startswith(prefix+' FAILURE '):item['data']=json.loads(line[len(prefix+' FAILURE '):])
 return out
pairs=[]
for suite,before,after,prefix in [('chain','chain-entry-v9','v9-chain-applied','CHAIN MODEL'),('deadline','deadline-entry-v9','v9-deadline-applied','DEADLINE'),('late','late-entry-v9','v9-late-applied','LATE MODEL')]:
 b=parse(before,prefix);a=parse(after,prefix);assert len(a)==len(b),(suite,len(a),len(b));assert [i['case']for i in a]==[i['case']for i in b]
 for x,y in zip(b,a):
  assert y['passed'];key=x['case'];classification='model-red-to-green'
  note='Falha contra o helper exato 251191…, aprovação modelada da versão final; não é Chromium.'
  if x['passed']:classification='already-passed-entry';note='Proteção/comportamento já aprovado na entrada; não declarar RED novo.'
  elif suite=='chain'and'unsupported-'in key:classification='explicit-rejection-contract-only';note='Entrada já rejeita por timeout; regressão exige diagnóstico UnsupportedScrollError, não prova clique inseguro.'
  elif suite=='chain'and'geometria-nao-dispensa-fins-retidos'in key:classification='entry-blocked-before-specific-boundary';note='Entrada ON já bloqueia por ignorar eventos internos; RED específico de liberação precoce é o intermediário v8, não a entrada.'
  elif suite=='late'and'clock-queued'in key:classification='new-boundary-not-present-in-entry';note='Entrada não tem consulta/calibração de relógio; não inventar RED dessa operação na entrada.'
  elif suite=='late'and(key.startswith('ON ')and any(s in key for s in ['geometry-changes-between','stale-poll-'])):classification='entry-blocked-before-specific-boundary';note='Entrada ON bloqueia antes de atingir o estado específico; falha do caso não autentica esse RED particular.'
  elif suite=='late'and key=='OFF diagnostic-queued':classification='new-success-diagnostic-boundary-not-in-entry';note='Entrada OFF não consulta diagnóstico no sucesso, logo não exerce esta retenção; diagnóstico pendente no erro é exercitado pela suíte deadline.'
  elif suite=='late'and key=='OFF stale-poll-after-confirmed-close':classification='closed-controller-contract-only';note='Callback da entrada não confirma fechamento/no-op; este trace não demonstra mutação tardia da aplicação.'
  pairs.append({'suite':suite,'case':key,'classification':classification,'note':note,'entry':x,'final':y,'entryLog':f'logs/{before}.log','finalLog':f'logs/{after}.log'})
assert len(pairs)==63
(E/'per-case-v9.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2)+'\n')
rounds=[]
for i in range(1,6):
 p=W/'logs'/f'v9-concurrency-round-{i}.json';record=json.loads(p.read_text());assert record['exit']==1;assert record['beforeFingerprint']==record['afterFingerprint']==integrity['fingerprint'];assert not record['changedDuringRun']and not record['sourceChangesDuringRun'];rounds.append({'order':i,'run':record['name'],'exit':1,'seconds':record['seconds'],'logSha256':sha(p.with_suffix('.log').read_bytes()),'metadataSha256':sha(p.read_bytes()),'fingerprint':record['beforeFingerprint'],'status':'BLOCKED jsdom import; zero concurrency scenarios executed; not a green round'})
(E/'concurrency-five-v9.json').write_text(json.dumps({'newSequentialAttempts':rounds,'greenRounds':0,'historicalRunsReused':False},indent=2)+'\n')
summary={suite:{'entryPassed':sum(p['entry']['passed']for p in pairs if p['suite']==suite),'finalPassed':sum(p['final']['passed']for p in pairs if p['suite']==suite),'cases':sum(p['suite']==suite for p in pairs)}for suite in ['chain','deadline','late']};(E/'model-summary-v9.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'integrity':integrity,'models':summary,'classifications':{c:sum(x['classification']==c for x in pairs)for c in sorted(set(x['classification']for x in pairs))}},indent=2))
