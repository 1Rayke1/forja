from pathlib import Path
import subprocess,sys,os,json,hashlib,time,signal
W=Path(__file__).resolve().parent.parent;source=Path('/home/user/forja');name,variant=sys.argv[1:3];cmd=sys.argv[3:];root=source if variant=='checkout' else W/variant
sha=lambda b:hashlib.sha256(b).hexdigest()
def snapshot(at):
 result={}
 for folder,dirs,files in os.walk(at):
  dirs[:]=sorted(d for d in dirs if d not in ['.git','node_modules','.cache'])
  for name in sorted(files):
   p=Path(folder)/name
   if p.is_file()and not p.is_symlink():result[str(p.relative_to(at))]=sha(p.read_bytes())
 return result
fp=lambda d:sha(json.dumps(d,sort_keys=True,separators=(',',':')).encode())
a=snapshot(root);s0=snapshot(source);env={'PATH':os.environ['PATH'],'HOME':str(W/'home'),'TMPDIR':str(W/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','NODE_DISABLE_COMPILE_CACHE':'1','NODE_OPTIONS':'--require='+str(W/'instruments/local-only.cjs'),'FORJA_OBSERVER':str(W/'logs'/f'{name}.observer.jsonl'),'npm_config_cache':str(W/'npm-cache'),'npm_config_userconfig':'/dev/null','npm_config_update_notifier':'false','npm_config_audit':'false','npm_config_fund':'false','npm_config_ignore_scripts':'true','npm_config_offline':'true','GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}
start=time.monotonic();timeout=False
with(W/'logs'/f'{name}.log').open('w')as out:
 p=subprocess.Popen(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  rc=124
 elapsed=round(time.monotonic()-start,3);out.write(f'\nRUN exit={rc} seconds={elapsed} timeout={timeout}\n')
b=snapshot(root);s1=snapshot(source);changed=sorted(k for k in a.keys()|b.keys()if a.get(k)!=b.get(k));sourceChanged=sorted(k for k in s0.keys()|s1.keys()if s0.get(k)!=s1.get(k));record={'name':name,'variant':variant,'command':cmd,'exit':rc,'seconds':elapsed,'timeout':timeout,'beforeFingerprint':fp(a),'afterFingerprint':fp(b),'fileHashesBefore':a,'fileHashesAfter':b,'sourceBefore':fp(s0),'sourceAfter':fp(s1),'changedDuringRun':changed,'sourceChangesDuringRun':sourceChanged};(W/'logs'/f'{name}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items()if not k.startswith('fileHashes')},ensure_ascii=False));lines=(W/'logs'/f'{name}.log').read_text().splitlines();print('\n'.join(line[:1200]for line in lines[-24:]));sys.exit(rc if not changed and not sourceChanged else 99)
