/* E2E only. One Node monotonic budget covers every protocol await.
   Renderer commands also carry an expiring lease, so a queued command cannot
   start a scroll or install a reference after the operation has expired. */
export async function scrollToInteractable(page, selector) {
  const started = performance.now(), deadline = started + 4000;
  let phase = 'clock', controller, pollingResult, limits, snapshot, failure, finished = false;
  let cleanupConfirmed = false, disposed = false, lastDiagnostic = { reason: 'deadline' };
  const remaining = () => Math.max(0, deadline - performance.now());
  const timeout = () => {
    const error = new Error('Waiting failed: 4000ms integral scroll deadline exceeded');
    error.name = 'TimeoutError';
    error.interaction = { ...lastDiagnostic, phase, deadlineMs: 4000, elapsedMs: performance.now() - started,
      cleanupConfirmed, disposed, safety: 'No click is performed by this helper.' };
    return error;
  };
  let timer;
  const expired = new Promise((_, reject) => { timer = setTimeout(() => reject(timeout()), remaining()); });
  void expired.catch(() => {});
  const run = async (label, task) => {
    if (finished || !remaining()) throw timeout();
    phase = label;
    const work = Promise.resolve().then(() => {
      if (finished || !remaining()) throw timeout();
      return task(remaining());
    });
    return Promise.race([work, expired]);
  };
  try {
    // Read-only calibration. A delayed result cannot mutate the document.
    const clock = await run('clock', () => page.evaluate(() => ({ now: performance.now(), timeOrigin: performance.timeOrigin })));
    if (!Number.isFinite(clock?.now) || !Number.isFinite(clock?.timeOrigin)) throw new Error('Invalid renderer monotonic clock');
    // Subtract the completed round-trip conservatively: never grant the
    // renderer a later deadline. The 64ms reserve belongs to the SAME 4000ms
    // budget: 32ms for cleanup, 32ms with no permitted page mutations before
    // reporting/disposal. It is neither an extra timeout nor a sleep.
    const finalAt = clock.timeOrigin + clock.now + remaining();
    limits = { finalAt, expiresAt: finalAt - 64, cleanupUntil: finalAt - 32, timeoutMs: 4000 };
    controller = await run('prepare', () => page.evaluateHandle(installScrollController, selector, limits));
    await run('geometry', () => controller.evaluate((state, lease) => {
      if (performance.timeOrigin + performance.now() >= lease.expiresAt) return false;
      return state.sample(true);
    }, limits));
    pollingResult = await run('polling', left => page.waitForFunction((state, lease) => {
      if (performance.timeOrigin + performance.now() >= lease.expiresAt) return true;
      return state.sample();
    }, { polling: 'raf', timeout: Math.max(1, Math.floor(left)) }, controller, limits));
    if (pollingResult?.dispose) await run('polling-dispose', () => pollingResult.dispose());
    pollingResult = undefined;
    snapshot = await run('diagnostic', () => controller.evaluate(state => state.inspect()));
    lastDiagnostic = snapshot.diagnostic || lastDiagnostic;
    if (snapshot.outcome === 'unsupported') {
      const error = new Error('Unsupported scroll case: ' + (snapshot.diagnostic?.unsupported || snapshot.diagnostic?.reason));
      error.name = 'UnsupportedScrollError'; error.interaction = snapshot.diagnostic; throw error;
    }
    if (snapshot.outcome !== 'ready') failure = timeout();
  } catch (error) {
    failure = error;
    if (!snapshot && controller && remaining()) {
      try {
        snapshot = await run('diagnostic', () => controller.evaluate(state => state.inspect()));
        lastDiagnostic = snapshot.diagnostic || lastDiagnostic;
      } catch (diagnosticError) { if (diagnosticError.name === 'TimeoutError') failure = diagnosticError; }
    }
    if (failure.name === 'TimeoutError') failure = timeout();
  }
  try {
    if (controller && remaining()) {
      const requireReady = !failure && snapshot?.outcome === 'ready';
      const cleanup = await run('cleanup', () => controller.evaluate((state, lease, verify) => {
        if (performance.timeOrigin + performance.now() >= lease.cleanupUntil) return { cleanupConfirmed: false };
        return state.cleanup(verify);
      }, limits, requireReady));
      cleanupConfirmed = cleanup?.cleanupConfirmed === true;
      if (cleanup?.diagnostic) lastDiagnostic = cleanup.diagnostic;
      if (requireReady && cleanup?.ready !== true) {
        failure = new Error('Scroll state changed before cleanup; interaction refused');
        failure.name = 'InteractionRefusedError'; failure.interaction = lastDiagnostic;
      }
    }
    if (pollingResult?.dispose && remaining()) await run('polling-dispose', () => pollingResult.dispose());
    if (controller && remaining()) { await run('dispose', () => controller.dispose()); disposed = true; }
    // Without an acknowledged close, do not return early while a renderer
    // command can still hold a valid lease. Its expiry is within this budget.
    if (remaining() && (failure?.name === 'TimeoutError' || limits && !cleanupConfirmed)) await expired;
    if (!failure && (!cleanupConfirmed || !disposed)) throw new Error('Scroll cleanup/disposal not confirmed; interaction refused');
  } catch (error) {
    failure = error;
    if (remaining() && limits && !cleanupConfirmed) {
      try { await expired; } catch (expiryError) { failure = expiryError; }
    }
  }
  finally { finished = true; clearTimeout(timer); }
  if (!remaining()) failure = timeout();
  if (failure) {
    if (failure.name === 'TimeoutError') failure = timeout();
    throw failure;
  }
}
