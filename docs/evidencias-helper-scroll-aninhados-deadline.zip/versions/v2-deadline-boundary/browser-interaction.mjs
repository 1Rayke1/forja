/* Sincronização de testes, sem mudar o scroll/design ou Auth de produção. */
/* E2E only. One Node monotonic budget covers every protocol await.
   Renderer commands also carry an expiring lease, so a queued command cannot
   start a scroll or install a reference after the operation has expired. */
export async function scrollToInteractable(page, selector) {
  const started = performance.now(), deadline = started + 4000;
  let phase = 'clock', controller, pollingResult, limits, snapshot, failure, finished = false;
  let cleanupConfirmed = false, disposed = false, lastDiagnostic = { reason: 'deadline' };
  const remaining = () => Math.max(0, deadline - performance.now());
  const timeout = () => {
    const error = new Error('Waiting failed: 4000ms integral scroll deadline exceeded');
    error.name = 'TimeoutError';
    error.interaction = { ...lastDiagnostic, phase, deadlineMs: 4000, elapsedMs: performance.now() - started,
      cleanupConfirmed, disposed, safety: 'No click is performed by this helper.' };
    return error;
  };
  let timer;
  const expired = new Promise((_, reject) => { timer = setTimeout(() => reject(timeout()), remaining()); });
  void expired.catch(() => {});
  const run = async (label, task) => {
    if (finished || !remaining()) throw timeout();
    phase = label;
    const work = Promise.resolve().then(() => {
      if (finished || !remaining()) throw timeout();
      return task(remaining());
    });
    return Promise.race([work, expired]);
  };
  try {
    // Read-only calibration. A delayed result cannot mutate the document.
    const clock = await run('clock', () => page.evaluate(() => ({ now: performance.now(), timeOrigin: performance.timeOrigin })));
    if (!Number.isFinite(clock?.now) || !Number.isFinite(clock?.timeOrigin)) throw new Error('Invalid renderer monotonic clock');
    // Subtract the completed round-trip conservatively: never grant the
    // renderer a later deadline. The 64ms reserve belongs to the SAME 4000ms
    // budget; it is for reporting/cleanup, not an extra timeout or a sleep.
    const finalAt = clock.timeOrigin + clock.now + remaining();
    limits = { finalAt, expiresAt: finalAt - Math.min(64, remaining()), timeoutMs: 4000 };
    controller = await run('prepare', () => page.evaluateHandle(installScrollController, selector, limits, scrollProjector.toString()));
    await run('geometry', () => controller.evaluate((state, lease) => {
      if (performance.timeOrigin + performance.now() >= lease.expiresAt) return false;
      return state.sample(true);
    }, limits));
    pollingResult = await run('polling', left => page.waitForFunction(async (state, lease) => {
      if (performance.timeOrigin + performance.now() >= lease.expiresAt) return true;
      return state.sample();
    }, { polling: 'raf', timeout: Math.max(1, Math.floor(left)) }, controller, limits));
    if (pollingResult?.dispose) await run('polling-dispose', () => pollingResult.dispose());
    pollingResult = undefined;
    snapshot = await run('diagnostic', () => controller.evaluate(state => state.inspect()));
    lastDiagnostic = snapshot.diagnostic || lastDiagnostic;
    if (snapshot.outcome === 'unsupported') {
      const error = new Error('Unsupported scroll case: ' + (snapshot.diagnostic?.unsupported || snapshot.diagnostic?.reason));
      error.name = 'UnsupportedScrollError'; error.interaction = snapshot.diagnostic; throw error;
    }
    if (snapshot.outcome !== 'ready') failure = timeout();
  } catch (error) {
    failure = error;
    if (controller && remaining()) {
      try {
        snapshot = await run('diagnostic', () => controller.evaluate(state => state.inspect()));
        lastDiagnostic = snapshot.diagnostic || lastDiagnostic;
      } catch (diagnosticError) { if (diagnosticError.name === 'TimeoutError') failure = diagnosticError; }
    }
    if (failure.name === 'TimeoutError') failure = timeout();
  }
  try {
    if (controller && remaining()) {
      const cleanup = await run('cleanup', () => controller.evaluate((state, lease) => {
        if (performance.timeOrigin + performance.now() >= lease.finalAt) return { cleanupConfirmed: false };
        return state.cleanup();
      }, limits));
      cleanupConfirmed = cleanup?.cleanupConfirmed === true;
    }
    if (pollingResult?.dispose && remaining()) await run('polling-dispose', () => pollingResult.dispose());
    if (controller && remaining()) { await run('dispose', () => controller.dispose()); disposed = true; }
    if (failure?.name === 'TimeoutError' && remaining()) await expired;
    if (!failure && (!cleanupConfirmed || !disposed)) throw new Error('Scroll cleanup/disposal not confirmed; interaction refused');
  } catch (error) { failure = error; }
  finally { finished = true; clearTimeout(timer); }
  if (failure) {
    if (failure.name === 'TimeoutError') failure = timeout();
    throw failure;
  }
}

// Interim adaptation of the exact entry renderer, before chain repair.
function installScrollController(selector, lease) {
  if (performance.timeOrigin + performance.now() >= lease.expiresAt) return {
    sample: () => true, inspect: () => ({ outcome: 'timeout', diagnostic: { reason: 'expired-before-prepare' } }),
    cleanup: () => ({ cleanupConfirmed: true })
  };
  const state = (() => {
    const element = document.querySelector(selector);
    if (!element) throw new Error('Alvo de rolagem ausente: ' + selector);
    const root = document.scrollingElement, options = { block: 'center', inline: 'nearest' };
    const position = () => [root.scrollLeft, root.scrollTop];
    const near = (a, b) => a.every((value, index) => Math.abs(value - b[index]) < 1);
    // Referência inerte, sem scripts/URLs/dados do app. O CSSOM do navegador
    // escolhe o destino: não reimplementamos center/nearest, margens, padding
    // ou clamp. O iframe fixo não participa do layout/scroll da página real.
    const reference = document.createElement('iframe');
    reference.setAttribute('aria-hidden', 'true'); reference.tabIndex = -1;
    reference.setAttribute('sandbox', 'allow-same-origin'); reference.inert = true;
    reference.style.cssText = 'all:initial!important;position:fixed!important;inset:0!important;border:0!important;margin:0!important;padding:0!important;opacity:0!important;visibility:hidden!important;pointer-events:none!important;z-index:-2147483648!important;';
    document.documentElement.appendChild(reference);
    const state = { element, nativeEnd: 'onscrollend' in document, origin: position(), end: null, lastScrollTime: -Infinity, previous: null, stableFrames: 0, requests: 0 };
    const track = event => {
      if (event.target !== document && event.target !== root) return;
      if (!near(position(), state.origin)) state.requiresEnd = true;
      state.lastScrollTime = event.timeStamp; state.end = null;
    };
    const finish = event => {
      if ((event.target === document || event.target === root) && event.isTrusted &&
          event.timeStamp >= state.lastScrollTime && event.timeStamp >= state.requestTime) {
        state.end = { position: position(), time: event.timeStamp };
      }
    };
    state.cleanup = () => {
      document.removeEventListener('scroll', track, true);
      if (state.nativeEnd) document.removeEventListener('scrollend', finish, true);
      reference.remove();
    };
    try {
      const doc = reference.contentDocument;
      doc.open(); doc.write('<!doctype html><html><head></head><body><div></div><div></div></body></html>'); doc.close();
      const viewport = doc.documentElement, [extent, target] = doc.body.children;
      doc.body.style.cssText = 'margin:0;padding:0;border:0;';
      extent.style.cssText = 'margin:0;padding:0;border:0;';
      target.style.cssText = 'position:absolute;margin:0;padding:0;border:0;box-sizing:border-box;';
      state.geometry = () => {
        const box = element.getBoundingClientRect(), style = getComputedStyle(element), rootStyle = getComputedStyle(root);
        return {
          numbers: [innerWidth, innerHeight, root.clientWidth, root.clientHeight, root.scrollWidth, root.scrollHeight,
            root.scrollLeft + box.left, root.scrollTop + box.top, box.width, box.height],
          margins: ['Top', 'Right', 'Bottom', 'Left'].map(side => style['scrollMargin' + side]),
          paddings: ['Top', 'Right', 'Bottom', 'Left'].map(side => rootStyle['scrollPadding' + side]),
          writingMode: style.writingMode, direction: rootStyle.direction, rootWritingMode: rootStyle.writingMode,
          overflowX: rootStyle.overflowX, overflowY: rootStyle.overflowY,
          scrollbarWidth: rootStyle.scrollbarWidth, scrollbarGutter: rootStyle.scrollbarGutter
        };
      };
      state.destination = geometry => {
        const [width, height, , , scrollWidth, scrollHeight, left, top, boxWidth, boxHeight] = geometry.numbers;
        reference.style.setProperty('width', width + 'px', 'important');
        reference.style.setProperty('height', height + 'px', 'important');
        viewport.style.direction = geometry.direction; viewport.style.writingMode = geometry.rootWritingMode;
        viewport.style.overflowX = geometry.overflowX; viewport.style.overflowY = geometry.overflowY;
        viewport.style.scrollbarWidth = geometry.scrollbarWidth; viewport.style.scrollbarGutter = geometry.scrollbarGutter;
        extent.style.width = scrollWidth + 'px'; extent.style.height = scrollHeight + 'px';
        target.style.left = left + 'px'; target.style.top = top + 'px';
        target.style.width = boxWidth + 'px'; target.style.height = boxHeight + 'px'; target.style.writingMode = geometry.writingMode;
        ['Top', 'Right', 'Bottom', 'Left'].forEach((side, index) => {
          viewport.style['scrollPadding' + side] = geometry.paddings[index];
          target.style['scrollMargin' + side] = geometry.margins[index];
        });
        // nearest depende da origem do PEDIDO, não de uma pausa intermediária.
        reference.contentWindow.scrollTo({ left: state.origin[0], top: state.origin[1], behavior: 'instant' });
        target.scrollIntoView({ ...options, behavior: 'instant' });
        return [viewport.scrollLeft, viewport.scrollTop];
      };
      state.lastGeometry = state.geometry(); state.target = state.destination(state.lastGeometry);
      state.requiresEnd = !near(position(), state.target);
      state.request = () => {
        state.origin = position(); state.requestTime = performance.now(); state.end = null; state.requests++;
        element.scrollIntoView(options);
      };
      // Ambos os listeners existem ANTES do pedido, inclusive no modo instant.
      document.addEventListener('scroll', track, true);
      if (state.nativeEnd) document.addEventListener('scrollend', finish, true);
      state.request();
      state.sample = () => {
        const describe = reason => {
          state.diagnostic = { reason, connected: element.isConnected && document.querySelector(selector) === element,
            position: position(), destination: state.target, atDestination: near(position(), state.target),
            stableFrames: state.stableFrames, nativeEnd: state.nativeEnd, requiresEnd: state.requiresEnd,
            nativeReceived: !!state.end && near(position(), state.end.position), requests: state.requests };
          return false;
        };
        if (!element.isConnected || document.querySelector(selector) !== element) return describe('detached');
        const geometry = state.geometry(), old = state.lastGeometry;
        const unchanged = geometry.numbers.every((value, index) => Math.abs(value - old.numbers[index]) < 0.01) &&
          Object.keys(geometry).filter(key => key !== 'numbers').every(key => String(geometry[key]) === String(old[key]));
        if (!unchanged) {
          state.lastGeometry = geometry; state.target = state.destination(geometry);
          state.previous = null; state.stableFrames = 0;
          if (!near(position(), state.target)) {
            // Layout/limite mudou: deixar o próprio navegador retargetar o
            // pedido. Não teletransportar a página nem aceitar o destino velho.
            state.requiresEnd = true; state.origin = position(); state.target = state.destination(geometry); state.request();
          }
        }
        const box = element.getBoundingClientRect();
        const current = [...position(), box.left, box.top, box.width, box.height, ...geometry.numbers.slice(0, 6)];
        const same = state.previous?.every((value, index) => value === current[index]);
        state.previous = current;
        if (!near(position(), state.target)) { state.stableFrames = 0; return describe('destination'); }
        state.stableFrames = same ? state.stableFrames + 1 : 0;
        if (state.stableFrames < 2) return describe('unstable');
        if (state.nativeEnd && state.requiresEnd && (!state.end || !near(position(), state.end.position))) return describe('native-scrollend');
        if (element.matches(':disabled')) return describe('disabled');
        if (element.closest('[inert]')) return describe('inert');
        // Opacidade não é herdada como valor computado: percorrer ancestrais.
        for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
          const style = getComputedStyle(ancestor);
          if (style.display === 'none') return describe('display-none');
          if (Number(style.opacity) === 0) return describe('opacity');
          if (style.contentVisibility === 'hidden') return describe('content-visibility');
        }
        const style = getComputedStyle(element);
        if (style.visibility !== 'visible') return describe('visibility');
        if (style.pointerEvents === 'none') return describe('pointer-events');
        if (element.checkVisibility && !element.checkVisibility({ opacityProperty: true, visibilityProperty: true,
          checkOpacity: true, checkVisibilityCSS: true })) return describe('visibility');
        if (box.width <= 0 || box.height <= 0) return describe('empty-box');
        if (box.top < 0 || box.left < 0 || box.bottom > innerHeight || box.right > innerWidth) return describe('viewport');
        const top = document.elementFromPoint(box.left + box.width / 2, box.top + box.height / 2);
        if (top !== element && !element.contains(top)) return describe('covered');
        describe('ready'); return true;
      };
      return state;
    } catch (error) { state.cleanup(); throw error; }
  })();
  let ready = false;
  const previousSample = state.sample.bind(state), previousCleanup = state.cleanup.bind(state);
  state.sample = () => { if (performance.timeOrigin + performance.now() >= lease.expiresAt) return true; ready = previousSample(); return ready; };
  state.inspect = () => ({ outcome: ready ? 'ready' : 'waiting', diagnostic: state.diagnostic });
  state.cleanup = () => { previousCleanup(); return { cleanupConfirmed: true }; };
  return state;
}
function scrollProjector() {}
